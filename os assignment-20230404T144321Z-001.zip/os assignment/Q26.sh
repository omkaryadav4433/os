#!/bin/bash
sum=0
s=11


read -p "Enter the Number" n

for((i=1;i<=n;i++))
  do
     s=$(( (s*10) + 1))
     echo -n $s " " 
     sum=$((sum+s))
     done 
     echo $sum
