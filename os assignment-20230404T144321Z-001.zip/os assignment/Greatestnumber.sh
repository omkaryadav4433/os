#!/bin/bash

read -p "Enter the numbers " n1 n2 n3

if(( $n1 -gt $n2 && $n1 -gt $n3))
 then 
 echo "N1 is greatest Number"
 
 else if(( $n2 -gt $n1 && $n2 -gt $n3))
 then 
 echo "N2 is greatest number"
 
 else
 echo "n3 is greatest number "
 fi

