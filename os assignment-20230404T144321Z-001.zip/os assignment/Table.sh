#!/bin/bash
 
 read -p "Enter the Number" n
  for (( i=1; i<=n; i++ ))
  do
 for (( j=1; j<=10; j++ ))
 do 
   
echo -n " `expr $i \* $j` " " "

 done
  echo 
  done
