#!/bin/bash

read -p "Enter the Number" n

echo "The Odd Numbers are"


for (( i=1; i<=n; i=i+2 ))
do
echo -n $i " "

done
