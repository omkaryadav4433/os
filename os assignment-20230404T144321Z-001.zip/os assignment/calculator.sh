#!/bin/bash
 
read -p "Enter first no " a
read -p "Enter second no " b
echo "1 Add 2 Substract 3 Multiplication 4 Division "
read -p "Enter choice" ch
case $ch in
     1)
        echo "Addition answer is "
        expr $a + $b
     ;;
     2)
        echo "Substraction answer is "
        expr $a - $b
     ;;
     3)
        echo "Multiplication answer is "
        expr $a \* $b
     ;;
     4)
        echo "Division answer is "
        expr $a / $b
     ;;

     *)
       echo "enter valid choice"
     ;;
   esac      

