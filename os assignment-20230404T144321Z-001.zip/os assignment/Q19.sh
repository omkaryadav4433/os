#!/bin/bash



read -p "Enter the number" n

if((n%2!=0))
then
  
  for((i=0;i<=n;i++))
    do
        for((j=1;j<=i-1;j++))
          do
             echo -n " "
    done
    
    for((j=1;j<=2*i-1;j++))
         do
          echo "*"
    done 
   
           echo
    done
    fi

   
