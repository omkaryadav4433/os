#!/bin/bash
read -p "Enter the Number" n

for((i=1; i<=n; i++))
do
for((j=1; J<=i; j++))
  do
       echo -n " $n"
       n=$(( n + 1))
  done
  n=1
          echo
done
