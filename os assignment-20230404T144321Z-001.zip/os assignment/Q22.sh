#!/bin/bash
read -p "Enter a number " a
for ((i=1;i<=a;i++))
do
	for ((j=1;j<=i;j++))
	do
		if(( (i+j)%2 ==0 ))
		then
			echo -n "1"
		else
			echo -n "0"
		fi
	done
	echo
	
done
