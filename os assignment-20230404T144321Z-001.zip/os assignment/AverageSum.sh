#!/bin/bash


read -p "Enter the Numbers " n1 n2 n3 n4 n5 n6 n7 n8 n9 n10

echo "Sum of 10 Numbers is"
sum=`expr   $n1 + $n2 + $n3 + $n4 + $n5 + $n6 + $n7 + $n8 + $n9 + $n10`

echo "Average of 10 Numbers " 

echo `expr $sum / 10`  
 
 
