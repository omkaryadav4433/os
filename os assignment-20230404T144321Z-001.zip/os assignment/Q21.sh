#!/bin/bash


read -p "Enter the Number" n
s=9
sum=0
for((i=0;i<=n;i++))
do 
  s=$(( (s*10)+9 ))
  echo -n $s " "  
 sum=$((sum+s))
  
done 
echo $sum
