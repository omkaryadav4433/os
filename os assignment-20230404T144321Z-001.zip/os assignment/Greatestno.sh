#!/bin/bash

read -p "Enter first numbers" n1 
read -p "Enter second numbers" n2 
read -p "Enter third numbers" n3

if (( ( $n1>$n2 ) && ( $n1>$n3 ) ))
then 
 echo "$n1 is greatest Number"
elif (( ( $n2>$n1 ) && ( $n2>$n3 ) )) 
then 
 echo "$n2 is greatest number"
else
 echo "$n3 is greatest number"
fi

