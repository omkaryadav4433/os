#!/bin/bash
 read -p "Enter thr Number" n
 
 echo "The cube of Number is"
     expr $n \* $n \* $n
 
 
