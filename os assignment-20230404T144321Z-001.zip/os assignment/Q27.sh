#!/bin/bash

read -p "Enter the Number" n
sum=0
for((i=1;i<n;i++))
do 
echo $i
    if(($n%$i=0))
    then 
    sum=`expr $sum + $i`
    echo $sum
    else if((sum==n))
    then 
    echo "The number is perfect"
    else 
    echo "Number is not Perfect"
    fi
    fi
    done
    
