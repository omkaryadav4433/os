#!/bin/bash

read -p "Enter the Number" n
fact=1
while ((n>0))

do 
 	fact=$((fact*n))
 	n=$((n-1))
 
done
echo  $fact
