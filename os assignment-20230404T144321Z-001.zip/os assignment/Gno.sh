#!/bin/bash

read -p "Enter the Numbers" n1 n2 n3

if (( $n1 > $n2 && $n1 > $n3 ))
then 
echo "N1 is Greatest Number "

elif (( $n2 > $n1 && $n2 > $n3 ))
then 
echo "N2 is Greatest Number"
 
 else 
 echo "N3 is Greatest Number"
 
 fi
